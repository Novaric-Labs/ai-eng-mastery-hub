import Link from "next/link";

// Marketing landing — a Server Component so it's SEO-indexable and fast.
export default function Home() {
  return (
    <main className="wrap" style={{ paddingTop: 64, paddingBottom: 64 }}>
      <p style={{ color: "var(--accent2)", fontWeight: 600, fontSize: 13 }}>
        2026 EDITION · UPDATED JUNE 2026
      </p>
      <h1 style={{ fontSize: 40, letterSpacing: "-.02em", margin: "8px 0 12px" }}>
        Master production AI engineering.
      </h1>
      <p style={{ color: "var(--dim2)", fontSize: 18, maxWidth: 640 }}>
        Not prompt tricks — the real job: RAG, agents, harnesses, evals, cost and
        latency discipline, and the judgment to ship. 21 modules, quizzes,
        spaced-repetition flashcards, and production scenarios.
      </p>
      <div style={{ display: "flex", gap: 12, margin: "28px 0" }}>
        <Link href="/login" className="btn">
          Start free preview →
        </Link>
        <Link href="/pricing" className="btn ghost">
          See pricing
        </Link>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 14, marginTop: 20 }}>
        {[
          ["Foundations", "LLMs, prompting, context engineering, the 2026 model landscape"],
          ["RAG & Knowledge", "Pipelines, embeddings, vector DBs, memory, data engineering"],
          ["Agents & Harnesses", "Tools, loops, multi-agent, the harness that makes them reliable"],
          ["Production & Leadership", "Evals, guardrails, architecture, build/buy/wait judgment"],
        ].map(([h, b]) => (
          <div className="card" key={h}>
            <b>{h}</b>
            <p style={{ color: "var(--dim)", fontSize: 13.5, marginTop: 6 }}>{b}</p>
          </div>
        ))}
      </div>

      <p style={{ color: "var(--dim)", fontSize: 13.5, marginTop: 28 }}>
        Free preview: the orientation, glossary, and a full sample module — no
        card required.
      </p>
    </main>
  );
}
